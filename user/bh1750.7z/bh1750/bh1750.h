#ifndef __BH1750_H
#define __BH1750_H

#include "i2c.h"
float getlex(void);


#endif

